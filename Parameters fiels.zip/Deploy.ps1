﻿Login-AzureRmAccount 
Get-AzureRmSubscription
New-AzureRmResourceGroupDeployment -Name DSC_IIS -ResourceGroupName DSC -TemplateFile D:\Scripts\dsc-extension-iis-server-windows-vm\azuredeploy.json -TemplateParameterFile D:\Scripts\dsc-extension-iis-server-windows-vm\azuredeploy.parameters.json -Verbose